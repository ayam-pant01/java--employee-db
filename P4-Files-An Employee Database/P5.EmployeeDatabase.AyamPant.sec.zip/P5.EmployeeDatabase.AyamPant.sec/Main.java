/**
 * 
 * @author ayamp
 * @version 03/11/2023 This class runs the program for employee data base addition
 *          
 */
public class Main {
	public static void main(String[] args) {
		System.out.println("Welcome to Programming Assignment 4: An Employee Database - by Ayam Pant!\n");
		Payroll start = new Payroll();
		Payroll.displayMenu();
	}

}
